var express = require("express")
var proxy = require("http-proxy-middleware")
var cors = require("cors")
var app = express()
app.use(cors())

var options = {
    target: 'https://api-v2.chuangkit.com',
    pathRewrite: {
        "^/": "/"
    },
    changeOrigin: true
}
options.onProxyReq = (proxyReq) => {
    proxyReq.setHeader("Cookie", "grwng_uid=2ef6d3fe-45d6-457d-8479-8d0feb600a32")
    proxyReq.setHeader("Referer", "https://m.chuangkit.com/pages/home/index")
}
var options2 = {
    target: 'https://api.chuangkit.com',
    pathRewrite: {
        "^/api": "/"
    },
    changeOrigin: true
}
options2.onProxyReq = (proxyReq) => {
    proxyReq.setHeader("Cookie", "grwng_uid=2ef6d3fe-45d6-457d-8479-8d0feb600a32")
    proxyReq.setHeader("Referer", "https://m.chuangkit.com/pages/home/index")
}
app.use("/api", proxy(options2))

app.use(proxy(options))

app.listen(9527, function () { 
    console.log(`服务启动在9527`);
})