define( [
	"./class2type"
], function( class2type ) {
	"use strict";

	return class2type.toString;
} );
